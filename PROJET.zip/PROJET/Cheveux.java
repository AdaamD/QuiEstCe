public  enum  Cheveux { 
	CHAUVE  ,  COURT  ,  LONG  ; 
} 