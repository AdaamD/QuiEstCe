public  enum  Genre  { 
    MASCULIN ,  FEMININ ;  
} 