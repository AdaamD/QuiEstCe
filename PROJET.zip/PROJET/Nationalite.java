
public  enum  Nationalite  { 
ANGLAISE  ,  ALLEMANDE  ,  FINLANDAISE  ,  USA  ,   SERBE  ,  FRANCAISE ,  ARGENTINE  ,  IRLANDAISE ;   
} 