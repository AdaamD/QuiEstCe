public  enum  Pilosite { 
	IMBERBE  ,  BARBE  ;  
} 