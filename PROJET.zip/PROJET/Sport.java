public  enum  Sport  { 
    INDIVIDUEL ,  COLLECTIF ;  
} 