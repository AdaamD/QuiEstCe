

import javax.swing.*;
import javax.swing.table.TableColumn;

public class Test 
{
  public static void main(String args[]) 
  {
    JFrame f = new JFrame();
    f.setSize(450, 150);

    //Header de JTable 
    String[] columns = new String[] {
      "Id",
      "Nom", 
      "Adresse", 
      "Taux horaire"
    };

    //données pour JTable dans un tableau 2D
    Object[][] data = new Object[][] {
      {1, "Thomas", "Paris", 20.0 },
     
      
    };

    Nationalite[] nationalite = {Nationalite.ANGLAISE, Nationalite.ALLEMANDE, Nationalite.FINLANDAISE,
    Nationalite.USA, Nationalite.SERBE , Nationalite.ARGENTINE, Nationalite.IRLANDAISE,Nationalite.FRANCAISE };
                  JComboBox ld1 = new JComboBox(nationalite);

        Sport[] sport= { Sport.INDIVIDUEL , Sport.COLLECTIF};
                  JComboBox ld2= new JComboBox(sport);

f.add(ld1);
f.add(ld2);


    //crée un JTable avec des données
    JTable table = new JTable(data, columns);

    // récupérer la 3éme colonne 
    TableColumn col = table.getColumnModel().getColumn(1);
    // créer un ComboBox

    JComboBox  cb = new JComboBox();
    cb.addItem(ld1);

    f.add(cb);
   
   
    //définir l'éditeur par défaut
    col.setCellEditor(new DefaultCellEditor(cb));

    JScrollPane scroll = new JScrollPane(table);
    table.setFillsViewportHeight(true);




    
    //ajouter la table au frame
    f.getContentPane().add(scroll);
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    f.setVisible(true);
  }
}  




