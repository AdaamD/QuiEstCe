
public  enum  CouleurCheveux { 
	FONCE  ,  CLAIR  ; 
} 